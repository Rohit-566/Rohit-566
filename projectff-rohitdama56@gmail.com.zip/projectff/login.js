function check(){
  let emailid1=(document.getElementById("emailid").value);
  let epass2= (document.getElementById("epass").value);

    if(emailid1 === "admin@admin.com" && epass2 === "12345678"){
        alert("Login Successful");
       return false;
    }
    else{
        alert("Incorrect E-mail or Password")
    }
}

